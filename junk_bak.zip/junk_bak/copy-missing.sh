#!/bin/bash
mkdir -p dist/styles
touch dist/styles/content.css
cp -r styles/* dist/styles/ 2>/dev/null || :
cp -r icons/* dist/icons/ 2>/dev/null || :
cp -r _locales/* dist/_locales/ 2>/dev/null || :
cp manifest.json *.html dist/ 