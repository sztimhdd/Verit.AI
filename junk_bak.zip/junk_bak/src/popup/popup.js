/**
 * 弹出窗口脚本 - Verit.ai Fact Checker
 */

// 语言管理
class I18nManager {
  constructor() {
    this.messages = {
      en: {
        serviceStatus: 'Service Status',
        ready: 'Ready',
        initializing: 'Initializing',
        error: 'Error',
        analyze: 'Analyze',
        analyzing: 'Analyzing...',
        retry: 'Retry',
        infoText: 'Verit.ai uses advanced AI technology to help you quickly verify the credibility of web content.',
        provideFeedback: 'Provide Feedback',
        remainingCalls: 'Remaining Calls',
        networkError: 'Network Error',
        serviceUnavailable: 'Service Unavailable',
        invalidResponse: 'Invalid Response',
        unknownError: 'Unknown Error'
      },
      zh: {
        serviceStatus: '服务状态',
        ready: '正常',
        initializing: '初始化中',
        error: '错误',
        analyze: '开始核查',
        analyzing: '正在分析...',
        retry: '重试',
        infoText: 'Verit.ai 使用先进的 AI 技术帮助您快速核实网页内容的可信度。',
        provideFeedback: '提供反馈',
        remainingCalls: '剩余调用额',
        networkError: '网络错误',
        serviceUnavailable: '服务不可用',
        invalidResponse: '无效响应',
        unknownError: '未知错误'
      }
    };

    this.currentLang = 'zh';
    this.initialize();
  }

  // 初始化语言设置
  async initialize() {
    try {
      const settings = await chrome.storage.sync.get('veritai_settings');
      if (settings.veritai_settings && settings.veritai_settings.language) {
        this.currentLang = settings.veritai_settings.language;
      } else {
        // 获取浏览器语言设置
        const browserLang = navigator.language.split('-')[0];
        this.currentLang = this.messages[browserLang] ? browserLang : 'zh';
      }
    } catch (error) {
      console.error('初始化语言设置失败:', error);
    }

    this.updateUI();
  }

  // 获取翻译
  getMessage(key) {
    return this.messages[this.currentLang][key] || this.messages.zh[key] || key;
  }

  // 切换语言
  async setLanguage(lang) {
    if (this.messages[lang]) {
      this.currentLang = lang;
      
      try {
        await chrome.storage.sync.set({
          veritai_settings: {
            language: lang
          }
        });
      } catch (error) {
        console.error('保存语言设置失败:', error);
      }

      this.updateUI();
    }
  }

  // 更新UI文本
  updateUI() {
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.getAttribute('data-i18n');
      element.textContent = this.getMessage(key);
    });

    // 更新没有data-i18n属性的元素
    document.querySelector('.status-text').textContent = 
      `${this.getMessage('serviceStatus')}: ${this.getMessage('initializing')}`;
    
    document.querySelector('.button-text').textContent = this.getMessage('analyze');
    document.querySelector('.loading-indicator span').textContent = this.getMessage('analyzing');
    document.querySelector('.retry-button').textContent = this.getMessage('retry');
    document.querySelector('.info-text').textContent = this.getMessage('infoText');
    document.querySelector('.feedback-link span').textContent = this.getMessage('provideFeedback');
    document.querySelector('.quota-label').textContent = `${this.getMessage('remainingCalls')}:`;

    // 更新语言按钮状态
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-lang') === this.currentLang);
    });
  }
}

// 弹出窗口管理
class PopupManager {
  constructor() {
    this.state = {
      serviceStatus: 'initializing',
      isAnalyzing: false,
      lastError: null,
      quotaStatus: null
    };
    
    this.i18n = new I18nManager();
    this.elements = this.getElements();
    
    this.checkServiceStatusThrottled = this.throttle(this.checkServiceStatus.bind(this), 5000);
    
    this.setupPerformanceMonitoring();
    
    this.initialize();
  }

  // 获取DOM元素
  getElements() {
    return {
      statusIndicator: document.querySelector('.status-indicator'),
      statusIcon: document.querySelector('.status-icon'),
      statusText: document.querySelector('.status-text'),
      analyzeButton: document.querySelector('.primary-button'),
      loadingIndicator: document.querySelector('.loading-indicator'),
      errorSection: document.querySelector('.error-section'),
      errorMessage: document.querySelector('.error-message'),
      retryButton: document.querySelector('.retry-button'),
      quotaInfo: document.querySelector('.quota-info'),
      groundingQuota: document.querySelector('.grounding-quota')
    };
  }

  // 初始化
  async initialize() {
    console.log('初始化PopupManager...');
    
    // 设置事件监听
    this.setupEventListeners();
    
    // 检查服务状态
    await this.checkServiceStatus();
    
    // 设置定期检查
    setInterval(() => this.checkServiceStatus(), 30000);
  }

  // 设置事件监听
  setupEventListeners() {
    // 分析按钮点击
    this.elements.analyzeButton.addEventListener('click', () => {
      this.handleAnalyzeClick();
    });
    
    // 重试按钮点击
    this.elements.retryButton.addEventListener('click', () => {
      this.checkServiceStatus();
    });
    
    // 语言切换按钮点击
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.i18n.setLanguage(btn.getAttribute('data-lang'));
      });
    });
    
    // 反馈链接点击
    document.querySelector('.feedback-link').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://github.com/yourusername/factchecker_ai/issues' });
    });
  }

  // 设置性能监控
  setupPerformanceMonitoring() {
    if (window.performance && window.performance.mark) {
      window.performance.mark('popup_init_start');
      
      window.addEventListener('load', () => {
        window.performance.mark('popup_init_end');
        window.performance.measure('popup_init_time', 'popup_init_start', 'popup_init_end');
        
        const measures = window.performance.getEntriesByType('measure');
        console.log('弹出窗口初始化时间:', measures[0].duration.toFixed(2), 'ms');
      });
    }
  }

  // 检查服务状态
  async checkServiceStatus() {
    try {
      console.log('检查服务状态...');
      window.performance?.mark?.('health_check_start');
      
      const response = await chrome.runtime.sendMessage({
        action: 'CHECK_SERVICE_STATUS'
      });
      
      window.performance?.mark?.('health_check_end');
      window.performance?.measure?.('health_check_time', 'health_check_start', 'health_check_end');
      
      const measures = window.performance?.getEntriesByType?.('measure') || [];
      const healthCheckTime = measures.find(m => m.name === 'health_check_time');
      if (healthCheckTime) {
        console.log('健康检查响应时间:', healthCheckTime.duration.toFixed(2), 'ms');
      }
      
      console.log('服务状态响应:', response);
      
      if (response.success) {
        this.setState({
          serviceStatus: response.status,
          quotaStatus: response.quotaStatus
        });
      } else {
        this.setState({
          serviceStatus: 'error',
          lastError: response.error
        });
      }
    } catch (error) {
      console.error('检查服务状态出错:', error);
      this.setState({
        serviceStatus: 'error',
        lastError: this.getErrorMessage(error)
      });
    }
  }

  // 处理分析按钮点击
  async handleAnalyzeClick() {
    if (this.state.isAnalyzing) {
      return;
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) {
        throw new Error('无法获取当前标签页');
      }

      this.setState({ isAnalyzing: true });
      this.showLoading();

      // 获取页面内容
      console.log('正在获取页面内容...');
      const content = await this.getPageContent(tab.id);
      
      // 发送分析请求
      console.log('发送分析请求...');
      const response = await chrome.runtime.sendMessage({
        action: 'ANALYZE_CONTENT',
        data: {
          content: content,
          url: tab.url,
          title: tab.title,
          lang: this.i18n.currentLang
        }
      });

      if (!response.success) {
        throw new Error(response.error);
      }

      // 显示浮动卡片结果
      await chrome.runtime.sendMessage({
        action: 'SHOW_FLOATING_CARD',
        data: response.data
      });

      // 关闭popup
      window.close();

    } catch (error) {
      console.error('分析过程出错:', error);
      this.handleAnalysisError(error);
    }
  }

  // 获取页面内容
  async getPageContent(tabId) {
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId },
        function: () => {
          return document.body.innerText;
        }
      });
      return result[0].result;
    } catch (error) {
      console.error('获取页面内容失败:', error);
      throw new Error('无法获取页面内容');
    }
  }

  // 处理分析错误
  handleAnalysisError(error) {
    this.setState({
      isAnalyzing: false,
      lastError: this.getErrorMessage(error)
    });
    this.showError(this.getErrorMessage(error));
  }

  // 获取错误消息
  getErrorMessage(error) {
    if (!error) return this.i18n.getMessage('unknownError');
    
    if (error.name === 'TypeError' || error.message.includes('网络') || error.message.includes('network')) {
      return this.i18n.getMessage('networkError');
    }
    
    if (error.message.includes('503') || error.message.includes('service') || error.message.includes('服务')) {
      return this.i18n.getMessage('serviceUnavailable');
    }
    
    if (error.message.includes('invalid') || error.message.includes('无效')) {
      return this.i18n.getMessage('invalidResponse');
    }
    
    return error.message || this.i18n.getMessage('unknownError');
  }

  // 设置状态
  setState(newState) {
    console.log('状态更新:', newState);
    this.state = { ...this.state, ...newState };
    this.updateUI();
  }

  // 更新UI
  updateUI() {
    // 更新服务状态指示器
    this.elements.statusIcon.className = 'status-icon';
    this.elements.statusIcon.classList.add(this.state.serviceStatus);
    
    this.elements.statusText.textContent = 
      `${this.i18n.getMessage('serviceStatus')}: ${this.i18n.getMessage(this.state.serviceStatus)}`;
    
    // 更新按钮状态
    const isServiceReady = this.state.serviceStatus === 'ready';
    this.elements.analyzeButton.disabled = !isServiceReady || this.state.isAnalyzing;
    
    // 更新配额信息
    if (this.state.quotaStatus && isServiceReady) {
      this.elements.quotaInfo.style.display = 'block';
      this.elements.groundingQuota.textContent = this.state.quotaStatus.groundingRemaining || 'N/A';
    } else {
      this.elements.quotaInfo.style.display = 'none';
    }
    
    // 更新错误显示
    if (this.state.lastError && this.state.serviceStatus === 'error') {
      this.showError(this.state.lastError);
    } else {
      this.hideError();
    }
    
    // 更新加载状态
    if (this.state.isAnalyzing) {
      this.showLoading();
    } else {
      this.hideLoading();
    }
  }

  // 显示加载状态
  showLoading() {
    this.elements.loadingIndicator.style.display = 'flex';
    this.elements.analyzeButton.disabled = true;
  }

  // 隐藏加载状态
  hideLoading() {
    this.elements.loadingIndicator.style.display = 'none';
    this.elements.analyzeButton.disabled = this.state.serviceStatus !== 'ready';
  }

  // 显示错误
  showError(message) {
    this.elements.errorMessage.textContent = message;
    this.elements.errorSection.style.display = 'block';
    this.elements.errorSection.classList.add('fade-in');
  }

  // 隐藏错误
  hideError() {
    this.elements.errorSection.style.display = 'none';
  }

  // 节流函数
  throttle(func, delay) {
    let lastCall = 0;
    return function(...args) {
      const now = new Date().getTime();
      if (now - lastCall < delay) {
        return;
      }
      lastCall = now;
      return func.apply(this, args);
    };
  }
}

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  console.log('Popup页面加载完成');
  window.popupManager = new PopupManager();
}); 