/**
 * 内容脚本 - Verit.ai Fact Checker
 * 
 * 负责:
 * - 与页面交互
 * - 插入浮动卡片
 * - 处理浮动卡片位置和行为
 */

// 状态管理
let contentState = {
  isCardVisible: false,
  cardPosition: { x: 20, y: 20 },
  lastAnalysisData: null
};

// 初始化
function initialize() {
  console.log('Verit.ai 内容脚本已初始化');
  
  // 监听来自background的消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('内容脚本收到消息:', message);
    
    switch (message.action) {
      case 'SHOW_FLOATING_CARD':
        showFloatingCard(message.data);
        sendResponse({ success: true });
        break;
        
      case 'HIDE_FLOATING_CARD':
        hideFloatingCard();
        sendResponse({ success: true });
        break;
        
      case 'GET_PAGE_CONTENT':
        const content = getPageContent();
        sendResponse({ success: true, content });
        break;
        
      default:
        console.log('未知消息操作:', message.action);
        sendResponse({ success: false, error: '未知操作' });
    }
    
    return true;
  });
}

/**
 * 显示浮动卡片
 * @param {Object} data 分析结果数据
 */
function showFloatingCard(data) {
  console.log('显示浮动卡片, 数据:', data);
  
  // 保存最新分析数据
  contentState.lastAnalysisData = data;
  
  // 如果卡片已存在，则更新内容
  if (contentState.isCardVisible) {
    updateFloatingCardContent(data);
    return;
  }
  
  // 创建 iframe 容器
  const iframe = document.createElement('iframe');
  iframe.id = 'veritai-floating-card-iframe';
  iframe.src = chrome.runtime.getURL('src/floating-card/floating-card.html');
  iframe.style.cssText = `
    position: fixed;
    z-index: 2147483647;
    top: ${contentState.cardPosition.y}px;
    left: ${contentState.cardPosition.x}px;
    width: 360px;
    height: 480px;
    border: none;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    background-color: transparent;
  `;
  
  // 添加到页面
  document.body.appendChild(iframe);
  contentState.isCardVisible = true;
  
  // 等待iframe加载完成后发送数据
  iframe.onload = function() {
    setTimeout(() => {
      if (iframe.contentWindow) {
        iframe.contentWindow.postMessage({
          action: 'INIT_FLOATING_CARD',
          data: contentState.lastAnalysisData,
          position: contentState.cardPosition
        }, '*');
      }
    }, 300);
  };
  
  // 监听来自 iframe 的消息
  setupIframeMessageListener();
}

/**
 * 设置iframe消息监听
 */
function setupIframeMessageListener() {
  window.addEventListener('message', function(event) {
    // 验证消息来源
    if (!event.data || !event.data.action) return;
    
    switch (event.data.action) {
      case 'CARD_POSITION_CHANGED':
        contentState.cardPosition = event.data.position;
        break;
        
      case 'CLOSE_FLOATING_CARD':
        hideFloatingCard();
        break;
        
      case 'CARD_READY':
        // iframe已准备好，发送数据
        const iframe = document.getElementById('veritai-floating-card-iframe');
        if (iframe && iframe.contentWindow) {
          iframe.contentWindow.postMessage({
            action: 'UPDATE_CARD_CONTENT',
            data: contentState.lastAnalysisData
          }, '*');
        }
        break;
    }
  });
}

/**
 * 更新浮动卡片内容
 * @param {Object} data 分析结果数据
 */
function updateFloatingCardContent(data) {
  const iframe = document.getElementById('veritai-floating-card-iframe');
  if (iframe && iframe.contentWindow) {
    iframe.contentWindow.postMessage({
      action: 'UPDATE_CARD_CONTENT',
      data: data
    }, '*');
  }
}

/**
 * 隐藏浮动卡片
 */
function hideFloatingCard() {
  const iframe = document.getElementById('veritai-floating-card-iframe');
  if (iframe) {
    iframe.remove();
    contentState.isCardVisible = false;
  }
}

/**
 * 获取页面内容
 * @returns {Object} 页面内容
 */
function getPageContent() {
  try {
    // 基本元数据
    const metadata = {
      title: document.title,
      url: window.location.href,
      domain: window.location.hostname
    };
    
    // 提取主要内容
    const content = extractMainContent();
    
    return {
      metadata,
      content
    };
  } catch (error) {
    console.error('获取页面内容失败:', error);
    return {
      metadata: {
        title: document.title,
        url: window.location.href
      },
      content: document.body.innerText.slice(0, 10000)
    };
  }
}

/**
 * 提取页面主要内容
 * @returns {string} 主要内容文本
 */
function extractMainContent() {
  // 尝试找到主要内容容器
  const contentSelectors = [
    'article',
    'main',
    '[role="main"]',
    '#content',
    '.content',
    '.article-content',
    '.post-content'
  ];
  
  for (const selector of contentSelectors) {
    const element = document.querySelector(selector);
    if (element && element.textContent.length > 100) {
      return element.innerText;
    }
  }
  
  // 如果无法找到明确的内容区域，返回body文本
  return document.body.innerText.slice(0, 10000);
}

// 初始化
initialize(); 