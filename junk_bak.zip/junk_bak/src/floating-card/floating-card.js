/**
 * 浮动卡片脚本 - Verit.ai Fact Checker
 * 
 * 负责:
 * - 显示分析结果
 * - 处理卡片拖动
 * - 管理卡片状态和交互
 */

// 语言管理
const I18n = {
  zh: {
    title: 'Verit.ai 分析结果',
    analysisComplete: '分析完成',
    loading: '正在加载分析结果...',
    error: '加载分析结果时出错',
    credibilityScore: '可信度评分',
    keyFindings: '关键发现',
    detailedAnalysis: '详细分析',
    factualConsistency: '事实一致性',
    topicFairness: '主题公正性',
    sourceReliability: '来源可靠性',
    referenceSources: '参考来源',
    share: '分享',
    feedback: '反馈',
    poweredBy: '由 Verit.ai 提供技术支持',
    low: '低',
    medium: '中',
    high: '高',
    noReferences: '没有找到参考来源'
  },
  en: {
    title: 'Verit.ai Analysis Results',
    analysisComplete: 'Analysis Complete',
    loading: 'Loading analysis results...',
    error: 'Error loading analysis results',
    credibilityScore: 'Credibility Score',
    keyFindings: 'Key Findings',
    detailedAnalysis: 'Detailed Analysis',
    factualConsistency: 'Factual Consistency',
    topicFairness: 'Topic Fairness',
    sourceReliability: 'Source Reliability',
    referenceSources: 'Reference Sources',
    share: 'Share',
    feedback: 'Feedback',
    poweredBy: 'Powered by Verit.ai',
    low: 'Low',
    medium: 'Medium',
    high: 'High',
    noReferences: 'No reference sources found'
  }
};

// 卡片管理
class FloatingCardManager {
  constructor() {
    this.cardData = null;
    this.position = { x: 20, y: 20 };
    this.isDragging = false;
    this.dragOffset = { x: 0, y: 0 };
    this.currentLang = 'zh';
    this.isMinimized = false;
    
    this.elements = this.getElements();
    this.setupEventListeners();
    this.notifyReady();
  }
  
  // 获取DOM元素
  getElements() {
    return {
      card: document.querySelector('.floating-card'),
      dragHandle: document.getElementById('drag-handle'),
      closeButton: document.querySelector('.close-button'),
      minimizeButton: document.querySelector('.minimize-button'),
      cardContent: document.querySelector('.card-content'),
      statusBanner: document.querySelector('.status-banner'),
      statusMessage: document.querySelector('.status-message'),
      loadingIndicator: document.querySelector('.loading-indicator'),
      errorMessage: document.querySelector('.error-message'),
      errorText: document.querySelector('.error-text'),
      credibilityScore: document.getElementById('credibility-score-value'),
      credibilityFill: document.getElementById('credibility-score-fill'),
      keyFindingsList: document.getElementById('key-findings-list'),
      factualConsistencyMeter: document.getElementById('factual-consistency-meter'),
      factualConsistencyValue: document.getElementById('factual-consistency-value'),
      topicFairnessMeter: document.getElementById('topic-fairness-meter'),
      topicFairnessValue: document.getElementById('topic-fairness-value'),
      sourceReliabilityMeter: document.getElementById('source-reliability-meter'),
      sourceReliabilityValue: document.getElementById('source-reliability-value'),
      referenceList: document.getElementById('reference-list'),
      shareButton: document.getElementById('share-button'),
      feedbackButton: document.getElementById('feedback-button'),
      collapseButtons: document.querySelectorAll('.collapse-button')
    };
  }
  
  // 设置事件监听
  setupEventListeners() {
    // 拖动功能
    this.elements.dragHandle.addEventListener('mousedown', this.handleDragStart.bind(this));
    document.addEventListener('mousemove', this.handleDragMove.bind(this));
    document.addEventListener('mouseup', this.handleDragEnd.bind(this));
    
    // 最小化按钮
    this.elements.minimizeButton.addEventListener('click', this.toggleMinimize.bind(this));
    
    // 关闭按钮
    this.elements.closeButton.addEventListener('click', this.closeCard.bind(this));
    
    // 折叠按钮
    this.elements.collapseButtons.forEach(button => {
      button.addEventListener('click', () => {
        this.toggleCollapsible(button.getAttribute('data-target'));
      });
    });
    
    // 分享按钮
    this.elements.shareButton.addEventListener('click', this.handleShare.bind(this));
    
    // 反馈按钮
    this.elements.feedbackButton.addEventListener('click', this.handleFeedback.bind(this));
    
    // 监听消息事件
    window.addEventListener('message', this.handleMessage.bind(this));
  }
  
  // 通知内容脚本卡片已就绪
  notifyReady() {
    window.parent.postMessage({ action: 'CARD_READY' }, '*');
  }
  
  // 处理拖动开始
  handleDragStart(e) {
    if (e.target.closest('.action-button')) return;
    
    this.isDragging = true;
    const rect = this.elements.card.getBoundingClientRect();
    this.dragOffset = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
    
    e.preventDefault();
  }
  
  // 处理拖动移动
  handleDragMove(e) {
    if (!this.isDragging) return;
    
    const newX = e.clientX - this.dragOffset.x;
    const newY = e.clientY - this.dragOffset.y;
    
    // 确保卡片不会拖出可视区域
    const maxX = window.innerWidth - this.elements.card.offsetWidth;
    const maxY = window.innerHeight - this.elements.card.offsetHeight;
    
    this.position = {
      x: Math.max(0, Math.min(newX, maxX)),
      y: Math.max(0, Math.min(newY, maxY))
    };
    
    window.parent.postMessage({
      action: 'CARD_POSITION_CHANGED',
      position: this.position
    }, '*');
  }
  
  // 处理拖动结束
  handleDragEnd() {
    this.isDragging = false;
  }
  
  // 切换最小化状态
  toggleMinimize() {
    this.isMinimized = !this.isMinimized;
    
    if (this.isMinimized) {
      this.elements.cardContent.style.display = 'none';
      this.elements.minimizeButton.innerHTML = '<i class="fas fa-expand"></i>';
      this.elements.minimizeButton.title = '展开';
      
      // 发送消息更新iframe大小
      window.parent.postMessage({
        action: 'RESIZE_CARD',
        size: { width: 360, height: 40 }
      }, '*');
    } else {
      this.elements.cardContent.style.display = 'block';
      this.elements.minimizeButton.innerHTML = '<i class="fas fa-minus"></i>';
      this.elements.minimizeButton.title = '最小化';
      
      // 发送消息更新iframe大小
      window.parent.postMessage({
        action: 'RESIZE_CARD',
        size: { width: 360, height: 480 }
      }, '*');
    }
  }
  
  // 关闭卡片
  closeCard() {
    window.parent.postMessage({ action: 'CLOSE_FLOATING_CARD' }, '*');
  }
  
  // 处理分享按钮点击
  handleShare() {
    // 简单实现：复制URL到剪贴板
    const url = this.cardData?.metadata?.url || window.parent.location.href;
    navigator.clipboard.writeText(url)
      .then(() => {
        alert('已复制页面链接到剪贴板');
      })
      .catch(err => {
        console.error('无法复制链接:', err);
      });
  }
  
  // 处理反馈按钮点击
  handleFeedback() {
    window.open('https://github.com/yourusername/factchecker_ai/issues/new?template=feedback.md', '_blank');
  }
  
  // 切换折叠内容
  toggleCollapsible(targetId) {
    const content = document.getElementById(targetId);
    const button = document.querySelector(`[data-target="${targetId}"]`);
    
    if (content && button) {
      if (content.style.display === 'none') {
        content.style.display = 'block';
        button.classList.remove('collapsed');
      } else {
        content.style.display = 'none';
        button.classList.add('collapsed');
      }
    }
  }
  
  // 处理收到的消息
  handleMessage(event) {
    const message = event.data;
    
    if (!message || !message.action) return;
    
    switch (message.action) {
      case 'INIT_FLOATING_CARD':
        this.initializeCard(message.data, message.position);
        break;
        
      case 'UPDATE_CARD_CONTENT':
        this.updateCardContent(message.data);
        break;
        
      case 'SET_LANGUAGE':
        this.setLanguage(message.language);
        break;
    }
  }
  
  // 初始化卡片
  initializeCard(data, position) {
    if (position) {
      this.position = position;
    }
    
    this.updateCardContent(data);
  }
  
  // 更新卡片内容
  updateCardContent(data) {
    if (!data) {
      this.showError('没有收到有效数据');
      return;
    }
    
    this.cardData = data;
    this.hideLoading();
    this.hideError();
    
    // 更新可信度评分
    const score = data.credibilityScore || 0;
    this.elements.credibilityScore.textContent = score;
    this.elements.credibilityFill.style.width = `${score}%`;
    
    // 更新关键发现
    this.updateKeyFindings(data.keyFindings);
    
    // 更新详细分析
    this.updateDetailedAnalysis(data.detailedAnalysis);
    
    // 更新参考来源
    this.updateReferenceSources(data.references);
  }
  
  // 更新关键发现
  updateKeyFindings(findings = []) {
    const list = this.elements.keyFindingsList;
    list.innerHTML = '';
    
    if (!findings || findings.length === 0) {
      const li = document.createElement('li');
      li.textContent = '没有关键发现';
      list.appendChild(li);
      return;
    }
    
    findings.forEach(finding => {
      const li = document.createElement('li');
      const icon = document.createElement('i');
      
      // 根据发现类型设置图标
      if (finding.type === 'positive') {
        icon.className = 'fas fa-check-circle';
        icon.style.color = '#4caf50';
      } else if (finding.type === 'negative') {
        icon.className = 'fas fa-exclamation-circle';
        icon.style.color = '#f44336';
      } else if (finding.type === 'neutral') {
        icon.className = 'fas fa-info-circle';
        icon.style.color = '#2196f3';
      } else {
        icon.className = 'fas fa-circle';
        icon.style.color = '#757575';
      }
      
      li.appendChild(icon);
      li.appendChild(document.createTextNode(finding.text));
      list.appendChild(li);
    });
  }
  
  // 更新详细分析
  updateDetailedAnalysis(analysis = {}) {
    // 更新事实一致性
    const factualConsistency = analysis.factualConsistency || 0;
    this.elements.factualConsistencyMeter.style.width = `${factualConsistency}%`;
    this.elements.factualConsistencyValue.textContent = `${factualConsistency}%`;
    
    // 更新主题公正性
    const topicFairness = analysis.topicFairness || 0;
    this.elements.topicFairnessMeter.style.width = `${topicFairness}%`;
    this.elements.topicFairnessValue.textContent = `${topicFairness}%`;
    
    // 更新来源可靠性
    const sourceReliability = analysis.sourceReliability || 0;
    this.elements.sourceReliabilityMeter.style.width = `${sourceReliability}%`;
    this.elements.sourceReliabilityValue.textContent = `${sourceReliability}%`;
  }
  
  // 更新参考来源
  updateReferenceSources(references = []) {
    const list = this.elements.referenceList;
    list.innerHTML = '';
    
    if (!references || references.length === 0) {
      const li = document.createElement('li');
      li.textContent = this.getMessage('noReferences');
      list.appendChild(li);
      return;
    }
    
    references.forEach(reference => {
      const li = document.createElement('li');
      const link = document.createElement('a');
      link.href = reference.url;
      link.target = '_blank';
      link.textContent = reference.title || reference.url;
      link.title = reference.url;
      
      li.appendChild(link);
      list.appendChild(li);
    });
  }
  
  // 设置语言
  setLanguage(lang) {
    if (I18n[lang]) {
      this.currentLang = lang;
      this.updateUIText();
    }
  }
  
  // 更新UI文本
  updateUIText() {
    const text = I18n[this.currentLang];
    
    document.querySelector('.card-title').textContent = text.title;
    this.elements.statusMessage.textContent = text.analysisComplete;
    document.querySelector('.loading-indicator span').textContent = text.loading;
    document.querySelector('.error-text').textContent = text.error;
    
    document.querySelector('.section-header h3:nth-of-type(1)').textContent = text.credibilityScore;
    document.querySelector('.section-header h3:nth-of-type(2)').textContent = text.keyFindings;
    document.querySelector('.section-header h3:nth-of-type(3)').textContent = text.detailedAnalysis;
    document.querySelector('.section-header h3:nth-of-type(4)').textContent = text.referenceSources;
    
    this.elements.factualConsistencyValue.previousElementSibling.previousElementSibling.textContent = text.factualConsistency;
    this.elements.topicFairnessValue.previousElementSibling.previousElementSibling.textContent = text.topicFairness;
    this.elements.sourceReliabilityValue.previousElementSibling.previousElementSibling.textContent = text.sourceReliability;
    
    this.elements.shareButton.querySelector('span').textContent = text.share;
    this.elements.feedbackButton.querySelector('span').textContent = text.feedback;
    document.querySelector('.footer-branding span').textContent = text.poweredBy;
    
    document.querySelector('.score-labels').innerHTML = `
      <span>${text.low}</span>
      <span>${text.medium}</span>
      <span>${text.high}</span>
    `;
  }
  
  // 获取翻译文本
  getMessage(key) {
    return I18n[this.currentLang][key] || I18n.zh[key] || key;
  }
  
  // 显示错误
  showError(message) {
    this.hideLoading();
    this.elements.statusBanner.style.display = 'none';
    this.elements.errorText.textContent = message;
    this.elements.errorMessage.style.display = 'flex';
  }
  
  // 隐藏错误
  hideError() {
    this.elements.errorMessage.style.display = 'none';
    this.elements.statusBanner.style.display = 'flex';
  }
  
  // 显示加载中
  showLoading() {
    this.hideError();
    this.elements.statusBanner.style.display = 'none';
    this.elements.loadingIndicator.style.display = 'flex';
  }
  
  // 隐藏加载中
  hideLoading() {
    this.elements.loadingIndicator.style.display = 'none';
  }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
  window.floatingCard = new FloatingCardManager();
}); 