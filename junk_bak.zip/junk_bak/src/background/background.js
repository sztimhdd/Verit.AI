/**
 * 后台脚本 - Verit.ai Fact Checker
 * 
 * 负责:
 * - 管理扩展状态
 * - 处理消息通信
 * - 与API服务交互
 */

import { APIService } from '../services/api.js';
import { StorageManager } from '../core/storage.js';

// 初始化
const apiService = new APIService();
const storageManager = new StorageManager();

// 状态管理
let extensionState = {
  serviceStatus: 'initializing',
  isAnalyzing: false,
  lastAnalysisTime: null,
  lastError: null,
  quotaStatus: null
};

// 监听来自弹出窗口和内容脚本的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('后台脚本收到消息:', message);

  switch (message.action) {
    case 'GET_SERVICE_STATUS':
      handleGetServiceStatus(sendResponse);
      return true; // 异步响应
      
    case 'CHECK_SERVICE_STATUS':
      handleCheckServiceStatus(sendResponse);
      return true; // 异步响应
      
    case 'SHOW_FLOATING_CARD':
      handleShowFloatingCard(message.data, sender.tab.id);
      sendResponse({ success: true });
      return false;
      
    case 'ANALYZE_CONTENT':
      handleAnalyzeContent(message.data, sendResponse);
      return true; // 异步响应
      
    default:
      console.log('未知消息操作:', message.action);
      sendResponse({ success: false, error: '未知操作' });
      return false;
  }
});

// 处理服务状态请求
async function handleGetServiceStatus(sendResponse) {
  try {
    sendResponse({
      success: true,
      status: extensionState.serviceStatus,
      quotaStatus: extensionState.quotaStatus
    });
  } catch (error) {
    console.error('获取服务状态失败:', error);
    sendResponse({
      success: false,
      status: 'error',
      error: error.message
    });
  }
}

// 检查服务状态
async function handleCheckServiceStatus(sendResponse) {
  try {
    console.log('检查服务状态...');
    const healthResult = await apiService.checkHealth();
    
    extensionState.serviceStatus = healthResult.status;
    extensionState.quotaStatus = healthResult.quota;
    
    sendResponse({
      success: true,
      status: healthResult.status,
      quotaStatus: healthResult.quota
    });
    
  } catch (error) {
    console.error('健康检查失败:', error);
    extensionState.serviceStatus = 'error';
    extensionState.lastError = error.message;
    
    sendResponse({
      success: false,
      status: 'error',
      error: error.message
    });
  }
}

// 显示浮动卡片
function handleShowFloatingCard(data, tabId) {
  console.log('显示浮动卡片:', data);
  chrome.tabs.sendMessage(tabId, {
    action: 'SHOW_FLOATING_CARD',
    data: data
  });
}

// 分析内容
async function handleAnalyzeContent(data, sendResponse) {
  try {
    console.log('开始分析内容...');
    extensionState.isAnalyzing = true;
    
    const result = await apiService.analyzeContent(data);
    
    extensionState.isAnalyzing = false;
    extensionState.lastAnalysisTime = new Date();
    
    // 更新配额状态
    if (result.quota) {
      extensionState.quotaStatus = result.quota;
    }
    
    sendResponse({
      success: true,
      data: result.data
    });
    
  } catch (error) {
    console.error('内容分析失败:', error);
    extensionState.isAnalyzing = false;
    extensionState.lastError = error.message;
    
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

// 启动时初始化
async function initialize() {
  console.log('初始化后台脚本...');
  
  // 检查服务状态
  try {
    const healthResult = await apiService.checkHealth();
    extensionState.serviceStatus = healthResult.status;
    extensionState.quotaStatus = healthResult.quota;
    console.log('服务状态:', extensionState.serviceStatus);
  } catch (error) {
    console.error('健康检查失败:', error);
    extensionState.serviceStatus = 'error';
    extensionState.lastError = error.message;
  }
  
  // 加载存储的设置
  const settings = await storageManager.getSettings();
  console.log('加载设置:', settings);
}

// 初始化
initialize(); 