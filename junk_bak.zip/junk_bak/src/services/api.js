/**
 * API服务 - Verit.ai Fact Checker
 * 
 * 负责:
 * - 与后端API交互
 * - 处理API请求
 * - 错误处理
 */

// API基础URL
const API_BASE_URL = 'http://localhost:4000';

// API端点
const API_ENDPOINTS = {
  HEALTH: '/health',
  ANALYZE: '/api/extension/analyze'
};

/**
 * API服务类
 */
export class APIService {
  constructor() {
    this.baseUrl = API_BASE_URL;
    this.endpoints = API_ENDPOINTS;
  }

  /**
   * 健康检查
   * @returns {Promise<Object>} 健康检查结果
   */
  async checkHealth() {
    try {
      const response = await fetch(`${this.baseUrl}${this.endpoints.HEALTH}`);
      
      if (!response.ok) {
        throw new Error(`服务状态检查失败: ${response.status}`);
      }
      
      const data = await response.json();
      
      return {
        status: data.status,
        quota: data.quota
      };
    } catch (error) {
      console.error('健康检查失败:', error);
      throw error;
    }
  }

  /**
   * 分析内容
   * @param {Object} data 分析数据
   * @returns {Promise<Object>} 分析结果
   */
  async analyzeContent(data) {
    try {
      const response = await fetch(`${this.baseUrl}${this.endpoints.ANALYZE}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || `分析请求失败: ${response.status}`);
      }
      
      const result = await response.json();
      
      return {
        data: result.data,
        quota: result.quota
      };
    } catch (error) {
      console.error('内容分析请求失败:', error);
      throw error;
    }
  }

  /**
   * 构建API错误
   * @param {string} message 错误消息
   * @param {number} status 状态码
   * @returns {Error} 错误对象
   */
  buildError(message, status) {
    const error = new Error(message);
    error.status = status;
    return error;
  }
} 