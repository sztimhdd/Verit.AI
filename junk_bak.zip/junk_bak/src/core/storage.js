/**
 * 存储管理器 - Verit.ai Fact Checker
 * 
 * 负责:
 * - 管理用户设置
 * - 缓存分析结果
 * - 提供统一的存储接口
 */

// 存储键
const STORAGE_KEYS = {
  SETTINGS: 'veritai_settings',
  ANALYSIS_CACHE: 'veritai_analysis_cache',
  LAST_HEALTH_CHECK: 'veritai_last_health_check'
};

// 默认设置
const DEFAULT_SETTINGS = {
  language: 'zh',
  showFloatingCard: true,
  cacheResults: true,
  cacheExpirationHours: 24,
  autoCheckInterval: 30 // 服务状态检查间隔（秒）
};

/**
 * 存储管理器类
 */
export class StorageManager {
  constructor() {
    this.keys = STORAGE_KEYS;
    this.defaults = DEFAULT_SETTINGS;
  }

  /**
   * 获取用户设置
   * @returns {Promise<Object>} 用户设置
   */
  async getSettings() {
    try {
      const result = await chrome.storage.sync.get(this.keys.SETTINGS);
      const settings = result[this.keys.SETTINGS] || {};
      
      // 合并默认设置
      return { ...this.defaults, ...settings };
    } catch (error) {
      console.error('获取设置失败:', error);
      return this.defaults;
    }
  }

  /**
   * 保存用户设置
   * @param {Object} settings 用户设置
   * @returns {Promise<void>}
   */
  async saveSettings(settings) {
    try {
      await chrome.storage.sync.set({
        [this.keys.SETTINGS]: settings
      });
      console.log('设置已保存');
    } catch (error) {
      console.error('保存设置失败:', error);
      throw error;
    }
  }

  /**
   * 获取分析结果缓存
   * @param {string} url 网页URL
   * @returns {Promise<Object|null>} 缓存的分析结果
   */
  async getAnalysisCache(url) {
    try {
      const result = await chrome.storage.local.get(this.keys.ANALYSIS_CACHE);
      const cache = result[this.keys.ANALYSIS_CACHE] || {};
      
      if (!cache[url]) {
        return null;
      }
      
      const cachedItem = cache[url];
      
      // 检查缓存是否过期
      const now = new Date().getTime();
      const settings = await this.getSettings();
      const expirationMs = settings.cacheExpirationHours * 60 * 60 * 1000;
      
      if (now - cachedItem.timestamp > expirationMs) {
        // 缓存已过期，移除并返回null
        this.removeAnalysisCache(url);
        return null;
      }
      
      return cachedItem.data;
    } catch (error) {
      console.error('获取缓存失败:', error);
      return null;
    }
  }

  /**
   * 保存分析结果缓存
   * @param {string} url 网页URL
   * @param {Object} data 分析结果数据
   * @returns {Promise<void>}
   */
  async saveAnalysisCache(url, data) {
    try {
      const result = await chrome.storage.local.get(this.keys.ANALYSIS_CACHE);
      const cache = result[this.keys.ANALYSIS_CACHE] || {};
      
      // 更新缓存
      cache[url] = {
        data: data,
        timestamp: new Date().getTime()
      };
      
      await chrome.storage.local.set({
        [this.keys.ANALYSIS_CACHE]: cache
      });
      
      console.log('分析结果已缓存');
      await this.cleanExpiredCache();
    } catch (error) {
      console.error('保存缓存失败:', error);
    }
  }

  /**
   * 移除分析结果缓存
   * @param {string} url 网页URL
   * @returns {Promise<void>}
   */
  async removeAnalysisCache(url) {
    try {
      const result = await chrome.storage.local.get(this.keys.ANALYSIS_CACHE);
      const cache = result[this.keys.ANALYSIS_CACHE] || {};
      
      if (cache[url]) {
        delete cache[url];
        
        await chrome.storage.local.set({
          [this.keys.ANALYSIS_CACHE]: cache
        });
        
        console.log('缓存已移除');
      }
    } catch (error) {
      console.error('移除缓存失败:', error);
    }
  }

  /**
   * 清理过期缓存
   * @returns {Promise<void>}
   */
  async cleanExpiredCache() {
    try {
      const result = await chrome.storage.local.get(this.keys.ANALYSIS_CACHE);
      const cache = result[this.keys.ANALYSIS_CACHE] || {};
      
      const settings = await this.getSettings();
      const expirationMs = settings.cacheExpirationHours * 60 * 60 * 1000;
      const now = new Date().getTime();
      
      let hasChanges = false;
      
      // 检查并移除过期缓存
      for (const url in cache) {
        if (now - cache[url].timestamp > expirationMs) {
          delete cache[url];
          hasChanges = true;
        }
      }
      
      if (hasChanges) {
        await chrome.storage.local.set({
          [this.keys.ANALYSIS_CACHE]: cache
        });
        console.log('过期缓存已清理');
      }
    } catch (error) {
      console.error('清理缓存失败:', error);
    }
  }

  /**
   * 保存健康检查结果
   * @param {Object} data 健康检查数据
   * @returns {Promise<void>}
   */
  async saveHealthCheck(data) {
    try {
      await chrome.storage.local.set({
        [this.keys.LAST_HEALTH_CHECK]: {
          data: data,
          timestamp: new Date().getTime()
        }
      });
    } catch (error) {
      console.error('保存健康检查失败:', error);
    }
  }

  /**
   * 获取上次健康检查结果
   * @returns {Promise<Object|null>} 健康检查数据
   */
  async getLastHealthCheck() {
    try {
      const result = await chrome.storage.local.get(this.keys.LAST_HEALTH_CHECK);
      return result[this.keys.LAST_HEALTH_CHECK] || null;
    } catch (error) {
      console.error('获取健康检查失败:', error);
      return null;
    }
  }
} 